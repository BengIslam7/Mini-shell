#include <stdio.h>
#include <string.h>
#include <unistd.h>

void save(char *ch) {
  char *fn = "history.txt";

  // open the file for writing
  FILE *fp = fopen(fn, "a");
  if (fp == NULL) {
    printf("Error opening the file %s", fn);
  }
  // write to the text file

  fprintf(fp, "%s\n", ch);

  // close the file
  fclose(fp);
}

void history() {
  char *fn = "history.txt";

  // open the file for writing
  FILE *fp = fopen(fn, "r");
  if (fp == NULL) {
    printf("Error opening the file %s", fn);
  }
  // write to the text file
  char line[200];
  while (fgets(line, sizeof(line), fp)) {
    printf("%s", line);
  }

  // close the file
  fclose(fp);
}

int cd(char *c) {
  int ns = 0;
  int r;
  char ch[200];
  strcpy(ch, c);
  // Traverse a string and if it is non space character then, place it at index
  // non_space_count

  for (int i = 0; ch[i] != '\0'; i++) {
    if (ch[i] != ' ') {
      ch[ns] = ch[i];
      ns++; // non_space_count incremented
    }
  }

  // Finally placing final character at the string end
  ch[ns] = '\0';
  if (strstr(&ch[0], "c") != NULL && strstr(&ch[1], "d")) {
    char *to;
    to = strndup(&ch[2], strlen(ch));
    r = chdir(to);
    if (r == -1) {
      printf("%s", "No such file or directory\n");
    }
    return 1;
  } else if (strcmp(ch, "quit") == 0) {
    return (2);
  } else
    return 0;
}

char *deletelinebreak(char *ch) {
  char *pos;
  if ((pos = strchr(ch, '\n')) != NULL)
    *pos = '\0';
  return (ch);
}

void execution(char *com) {
  FILE *fp;
  int status;
  char path[200];
  int i = 0;
  fp = popen(com, "r");
  if (fp == NULL) {
    printf("%s", "handle error");
  } else {
    while (fgets(path, sizeof(path), fp) != NULL) {
      printf("%s", path);
    }
    status = pclose(fp);
  }
}

int main() {
  char copieh[500];
  char c[100];
  char *command;
  char cd1[100];
  char s[100];
  const char ch[] = ";";
  const char ch1[] = "&&";
  const char ch2[] = "||";
  while (1) {

    // printing current working directory
    printf("%s%%", getcwd(s, 100));
    fgets(c, sizeof(c), stdin);
    command = deletelinebreak(c);

    if (strstr(command, ch) != NULL || strstr(command, ch1) != NULL ||
        strstr(command, ch2) != NULL) {

      if (strstr(command, ch) != NULL) {
        char *ptr = strtok(command, ";");
        while (ptr != NULL) {
          if (cd(ptr) == 1) {
            save(ptr);
          } else if (cd(ptr) == 2) {
            return (0);
          } else {
            execution(ptr);
            save(ptr);
          }
          ptr = strtok(NULL, ";");
        }
      }
    }

    else if (strstr(command, ".bat") != NULL && strstr(command, " ") == NULL) {
      FILE *file = fopen(command, "r");
      if (file == NULL) {
        printf("%s\n", "Fichier batch non existant");
      } else {
        char line[200];
        while (fgets(line, sizeof(line), file)) {
          printf("%s", line);
          if (strstr(line, ";&|") != NULL) {
            char *ptr = strtok(deletelinebreak(line), ";&|");
            while (ptr != NULL) {
              execution(ptr);
              save(ptr);
              ptr = strtok(NULL, ";&|");
            }
          } else {
            execution(line);
            save(deletelinebreak(line));
          }
        }
      }

    }

    else if (strcmp(command, "history") == 0) {
      history();
    }

    else if (cd(command) == 1) {
      save(command);
    } else if (cd(command) == 2) {
      return (0);
    }

    else {
      execution(command);
      save(command);
    }
  }
}
